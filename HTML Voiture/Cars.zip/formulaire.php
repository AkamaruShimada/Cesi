<html>

<title>Formulaire</title>

<body>

<link rel="stylesheet" href="formulaire.css">

<div style="text-align: center">

<form action="insert.php" method="post">

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<strong>
    <br><font face="times new roman" size="+3" color="white">Remplissez le formulaire</font>
</strong>

<br>
<br>
<br>
<div id="inserer" style="text-align: center">

<input type="text" name="Marque" id="querry" placeholder="Insérer la marque" />
<input type="text" name="Modèle" id="querry" placeholder="Insérer le modèle" />
<input type="text" name="Carburant" id="querry" placeholder="Insérer le type de carburant" />

</div>

<input type="submit" id="entrer"/>

</form>

</div>

</body>
</html>
